
Female Starter Pack Script | BJ Development

Framework Compatibility: ESX & QBCore
Inventory Required: ox_inventory

This script adds a Female Starter Pack item to your server, allowing new female characters to receive starter items easily. Fully compatible with ESX and QBCore frameworks.
```
ESX Installation

Open your es_extended -> config.lua.

Add or update the following under your starter inventory settings:

Config.StartingInventoryItems = {
	female_starterpack = 1,
}


Add the new item to your ox_inventory -> data -> items.lua:

["female_starterpack"] = {
	label = "Female Starter Pack",
	weight = 3,
	stack = true,
	close = false,
	description = "Female Starter Pack",
	client = {
		image = "female_starterpack.png",
	}
},


Restart your server to apply changes.

QBCore Installation

Open qb-core -> shared -> main.lua and add the starter item:

QBShared.StarterItems = {
    ['female_starterpack'] = { amount = 1, item = 'starter_pack' },
}


Add the item to qb-core -> shared -> items.lua:

female_starterpack = { 
    name = 'female_starterpack', 
    label = 'Female Starter Pack', 
    weight = 300, 
    type = 'item', 
    image = 'female_starterpack.png', 
    unique = true, 
    useable = true, 
    shouldClose = false, 
    description = "Female Starter Pack" 
},


Restart your server to apply changes.

Notes

Make sure the item image (female_starterpack.png) exists in your inventory images folder.

Compatible with ox_inventory v2.40.2 and newer.

Designed for serious RP servers to give female characters a starting set of items efficiently.

Support

For support, updates, or customization requests, contact:
BJ Development